export type userType = {
    name: string
    hair: number
    address: {title: string}
}