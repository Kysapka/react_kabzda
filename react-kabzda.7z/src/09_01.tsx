import React from "react";

let User = {
    name: 'Artem',
    age: 36
}